﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyekSDP
{
    public partial class formKasir : Form
    {
        Image logoCari;
        public formKasir()
        {
            InitializeComponent();

        }

        private void formKasir_Load(object sender, EventArgs e)
        {
            logoCari = Image.FromFile(Application.StartupPath + "/cari.png");
            btnCariBrg.BackgroundImage = logoCari;
            btnCariBrg.BackgroundImageLayout = ImageLayout.Stretch;
            btnCariCustomer.BackgroundImage = logoCari;
            btnCariCustomer.BackgroundImageLayout = ImageLayout.Stretch;

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnCariBrg_Click(object sender, EventArgs e)
        {
            pilihBarang p = new pilihBarang();
            p.ShowDialog();
        }

        private void btnCariCustomer_Click(object sender, EventArgs e)
        {
            pilihCustomer p = new pilihCustomer();
            p.ShowDialog();
        }
    }
}
