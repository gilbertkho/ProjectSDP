﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyekSDP
{
    public partial class login : Form
    {
        int pilihMenu = 0;
        public login()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Size = new Size(1366, 768);
            this.Location = new Point(0, 0);
            this.BackgroundImage = Image.FromFile("images/login.jpg");
            this.BackgroundImageLayout = ImageLayout.Stretch;

            aturWidget();
        }

        public void aturWidget() {
            //untuk textbox username dan password
            textBox1.Size = new Size(300, 45);
            textBox1.Location = new Point(837, 338);
            textBox1.Font = new Font("arial", 25);
            textBox2.Size = new Size(300, 45);
            textBox2.Location = new Point(837, 450);
            textBox2.Font = new Font("arial", 25);
            
            panel1.Size = new Size(223, 40);
            panel1.Location = new Point(874, 533);
            panel1.BackColor = Color.Transparent;
        }
        
        private void login_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Brush brush = new SolidBrush(Color.FromArgb(64, Color.Gray));
            if (pilihMenu == 1) g.FillRectangle(brush, 874, 533, 223, 40);
            else if (pilihMenu == 2) g.FillRectangle(brush, 874, 601, 223, 40);
        }
        
        private void login_MouseHover(object sender, EventArgs e)
        {
            if (pilihMenu != 0)
            {
                pilihMenu = 0;
                this.Invalidate();
            }
        }
        private void panel1_MouseHover(object sender, EventArgs e)
        {
            if (pilihMenu != 1)
            {
                pilihMenu = 1;
                this.Invalidate();
            }
        }

        private void panel1_MouseClick(object sender, MouseEventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "")
            {
                Form1 f = new Form1();
                ((Form1)MdiParent).openMaster();
                this.Close();
            }
            else if (textBox1.Text == "kasir" && textBox2.Text == "kasir")
            {
                formKasir fk = new formKasir();
                ((Form1)MdiParent).openKasir();
                this.Close();
            }
            else if (textBox1.Text == "e" && textBox2.Text == "e")
            {
                EmployeePage fk = new EmployeePage();
                ((Form1)MdiParent).openEmp();
                this.Close();
            }
        }
    }
}
