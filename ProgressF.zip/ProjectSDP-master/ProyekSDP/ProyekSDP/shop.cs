﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyekSDP
{
    public partial class shop : Form
    {
        int pilihMenu = 0;

        int hargaTotal = 0;//untuk total harga

        public shop()
        {
            InitializeComponent();
        }

        private void openShop_Load(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            this.Size = new Size(800, 647);
            this.Location = new Point(0, 0);
            this.BackgroundImage = Image.FromFile("images/shop.jpg");
            this.BackgroundImageLayout = ImageLayout.Stretch;

            aturWidget();
        }

        public void aturWidget() {
            //list data yang dibeli
            listBox1.Location = new Point(463, 205);
            listBox1.Size = new Size(260, 225);
            listBox1.Font = new Font("arial", 12);

            //detail barang yang mau dibeli
            //supplier
            comboBox1.Location = new Point(209, 205);
            comboBox1.Size = new Size(223, 22);
            comboBox1.Font = new Font("arial", 12);
            //nama barang
            comboBox2.Location = new Point(209, 254);
            comboBox2.Size = new Size(223, 22);
            comboBox2.Font = new Font("arial", 12);
            //quantity
            numericUpDown1.Location = new Point(209, 303);
            numericUpDown1.Size = new Size(100, 22);
            numericUpDown1.Font = new Font("arial", 12);
            //untuk tipe yang mau dibeli box / strip / biji
            comboBox3.Location = new Point(322, 303);
            comboBox3.Size = new Size(110, 22);
            comboBox3.Font = new Font("arial", 12);

            //harga yang ingin dijual
            textBox1.Location = new Point(209, 352);
            textBox1.Size = new Size(223, 22);
            textBox1.Font = new Font("arial", 12);
            textBox1.Enabled = false;
            //tanggal expired
            dateTimePicker1.Location = new Point(209, 401);
            dateTimePicker1.Size = new Size(223, 22);
            dateTimePicker1.Font = new Font("arial", 12);

            //buat back
            panel1.Location = new Point(734, 36);
            panel1.Size = new Size(31, 40);
            panel1.BackColor = Color.Transparent;
            //buat tombol check out
            panel2.Location = new Point(564, 489);
            panel2.Size = new Size(157, 20);
            panel2.BackColor = Color.Transparent;
            //buat tombol +
            panel3.Location = new Point(461, 449);
            panel3.Size = new Size(23, 23);
            panel3.BackColor = Color.Transparent;
            //buat tombol -
            panel4.Location = new Point(505, 449);
            panel4.Size = new Size(23, 23);
            panel4.BackColor = Color.Transparent;


            //label untuk total harga
            label1.Text = "Rp. " + hargaTotal.ToString() + ",-";
            label1.Location = new Point(550, 449);
            label1.Size = new Size(170, 25);
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("arial", 15);
            label1.ForeColor = Color.White;
            label1.TextAlign = ContentAlignment.MiddleRight;
        }

        private void shop_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Brush brush = new SolidBrush(Color.FromArgb(64, Color.Gray));
            if (pilihMenu == 1) g.FillRectangle(brush, 734, 36, 31, 40);
            else if (pilihMenu == 2) g.FillRectangle(brush, 564, 489, 157, 20);
            else if (pilihMenu == 3) g.FillEllipse(brush, 461, 449, 23, 23);
            else if (pilihMenu == 4) g.FillEllipse(brush, 505, 449, 23, 23);
        }

        private void shop_MouseHover(object sender, EventArgs e)
        {
            if (pilihMenu != 0)
            {
                pilihMenu = 0;
                this.Invalidate();
            }
        }
        private void panel1_MouseHover(object sender, EventArgs e)
        {
            if (pilihMenu != 1)
            {
                pilihMenu = 1;
                this.Invalidate();
            }
        }
        private void panel2_MouseHover(object sender, EventArgs e)
        {
            if (pilihMenu != 2)
            {
                pilihMenu = 2;
                this.Invalidate();
            }
        }
        private void panel3_MouseHover(object sender, EventArgs e)
        {
            if (pilihMenu != 3)
            {
                pilihMenu = 3;
                this.Invalidate();
            }
        }
        private void panel4_MouseHover(object sender, EventArgs e)
        {
            if (pilihMenu != 4)
            {
                pilihMenu = 4;
                this.Invalidate();
            }
        }

        private void panel1_MouseClick(object sender, MouseEventArgs e)
        {
            Form1 f = new Form1();
            ((Form1)MdiParent).openMaster();
            this.Close();
        }
        private void panel2_MouseClick(object sender, MouseEventArgs e)
        {
            MessageBox.Show("CHECKOUT!!!");
        }
        private void panel3_MouseClick(object sender, MouseEventArgs e)
        {
            MessageBox.Show("+ barang");
        }
        private void panel4_MouseClick(object sender, MouseEventArgs e)
        {
            MessageBox.Show("- barang");
        }
    }
}
