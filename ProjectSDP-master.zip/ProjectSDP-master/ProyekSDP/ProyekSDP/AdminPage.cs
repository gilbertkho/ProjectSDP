﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyekSDP
{
    public partial class AdminPage : Form
    {
        public AdminPage()
        {
            InitializeComponent();
        }
       
        private void AdminPage_Load(object sender, EventArgs e)
        {
            this.Size = new Size(1366, 768);
            this.Location = new Point(0, 0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Stock");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Convert Barang");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            ((Form1)MdiParent).openShop();
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {

            Form1 f = new Form1();
            ((Form1)MdiParent).register();
            this.Close();
        }
    }
}
