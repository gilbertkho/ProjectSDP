﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyekSDP
{
    public partial class shop : Form
    {
        public shop()
        {
            InitializeComponent();
        }

        private void openShop_Load(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            this.Size = new Size(1366, 768);
            this.Location = new Point(0, 0);
        }
    }
}
