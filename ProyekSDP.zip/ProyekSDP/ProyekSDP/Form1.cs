﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyekSDP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            login();
        }

        public void login()
        {
            //this.Location = new Point(50, 0);
            //this.Size = new Size(1388, 812);
            login l = new login();
            l.MdiParent = this;
            l.Show();
        }

        //salah
        public void register()
        {
            //this.Location = new Point(350, 0);
            //this.Size = new Size(820, 850);
            register l = new register();
            l.MdiParent = this;
            l.Show();
        }

        public void openMaster() {
            //this.Location = new Point(50, 0);
            //this.Size = new Size(1388, 812);
            AdminPage ap = new AdminPage();
            ap.MdiParent = this;
            ap.Show();
        }

        public void openShop()
        {
            //this.Location = new Point(350, 0);
            //this.Size = new Size(820, 691);
            shop sh = new shop();
            sh.MdiParent = this;
            sh.Show();
        }

        public void openEmp()
        {
            //this.Location = new Point(50, 0);
            //this.Size = new Size(1388, 812);
            EmployeePage ep = new EmployeePage();
            ep.MdiParent = this;
            ep.Show();
        }

        public void openSupply()
        {
            //this.Location = new Point(350, 0);
            //this.Size = new Size(820, 691);
            OrderedSupply sh = new OrderedSupply();
            sh.MdiParent = this;
            sh.Show();
        }

    }
}
