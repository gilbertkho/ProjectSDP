﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyekSDP
{
    public partial class register : Form
    {
        public register()
        {
            InitializeComponent();
        }

        private void register_Load(object sender, EventArgs e)
        {
            //this.Size = new Size(800, 800);
            this.Location = new Point(0, 0);

            comboBox1.Items.Add("Cashier");
            comboBox1.Items.Add("Customer Member");
            comboBox1.Items.Add("Employee");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("REGISTERED!!!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            ((Form1)MdiParent).login();
            this.Close();
        }
    }
}
