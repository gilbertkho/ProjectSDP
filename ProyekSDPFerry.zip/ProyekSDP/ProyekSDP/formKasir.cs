﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;

namespace ProyekSDP
{
    public partial class formKasir : Form
    {
        Image logoCari;
        public OracleConnection oc;
        DataTable satuan_barang;
        public formKasir()
        {
            InitializeComponent();
            oc = new OracleConnection("user id=system; password=sby; data source=sby");
            oc.Open();
        }

        private void formKasir_Load(object sender, EventArgs e)
        {
            logoCari = Image.FromFile(Application.StartupPath + "/cari.png");
            btnCariBrg.BackgroundImage = logoCari;
            btnCariBrg.BackgroundImageLayout = ImageLayout.Stretch;
            btnCariCustomer.BackgroundImage = logoCari;
            btnCariCustomer.BackgroundImageLayout = ImageLayout.Stretch;

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnCariBrg_Click(object sender, EventArgs e)
        {
            pilihBarang p = new pilihBarang(this);
            p.ShowDialog();

        }
        public void setInfoBarang(string id, string nama, string harga)
        {
            txtKodeBarang.Text = id;
            txtNamaBarang.Text = nama;
            txtHargaBarang.Text = harga;
            string q = "select distinct jenis from d_barang where id_barang='" + id + "'";
            Console.WriteLine(q);
            satuan_barang = new DataTable();
            OracleDataAdapter oda = new OracleDataAdapter(q, oc);
            oda.Fill(satuan_barang);
            cbSatuan.DataSource = satuan_barang;
            cbSatuan.DisplayMember = "jenis";
        }

        private void btnCariCustomer_Click(object sender, EventArgs e)
        {
            pilihCustomer p = new pilihCustomer();
            p.ShowDialog();
        }
    }
}
