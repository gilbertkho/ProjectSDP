package com.example.tugasmdp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {

    Button btnSave;
    RadioButton radioMale, radioFemale;
    EditText txtNrp, txtHasil;
    String text = "";
    String temp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSave = findViewById(R.id.btnSave);
        radioMale = findViewById(R.id.rbMale);
        radioFemale = findViewById(R.id.rbFemale);
        txtNrp = findViewById(R.id.txtNrp);
        txtHasil = findViewById(R.id.txtHasil);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (txtNrp.getText().toString() != ""){
                    text += "NRP " + txtNrp.getText().toString() + ", gendernya ";
                    temp = txtHasil.getText().toString();
                    if (radioMale.isChecked()){
                        text += "male \n";
                        txtHasil.setText(temp + text);
                    } else if (radioFemale.isChecked()){
                        text += "female \n";
                        txtHasil.setText(temp + text);
                    }
                    Log.d("ferry", temp+text);
                    //txtHasil.setText(text);
                    text = "";
                    temp = "";

                }

            }
        });

    }
}
